<?php

namespace App\Lib\Themeable;

interface ThemeContract {}
