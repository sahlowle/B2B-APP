<?php

namespace App\Models;

class NotificationSetting extends Model
{
    protected $table = 'notification_settings';
}
