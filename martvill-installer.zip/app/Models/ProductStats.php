<?php

namespace App\Models;

class ProductStats extends Model
{
    protected $table = 'product_stats';

    public $timestamps = false;
}
