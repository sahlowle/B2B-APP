<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Avariamoney\\Providers\\AvariamoneyServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Avariamoney\\Providers\\AvariamoneyServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);